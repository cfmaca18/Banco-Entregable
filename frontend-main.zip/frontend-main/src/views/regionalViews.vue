<template>
    <div >

      <listaRegionales></listaRegionales>
    </div>
  </template>
  
  <script>
  // @ is an alias to /src
  
  import listaRegionales from '@/components/Regional.vue'


  export default {
   components:{
    listaRegionales,
  }
  
  }
    
  </script>
  