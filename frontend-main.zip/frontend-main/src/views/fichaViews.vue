<template>
    <div >
      <ficha></ficha> 
    </div>
</template>

<script>
import ficha from '@/components/ficha.vue'
export default {
components:{
  ficha
}

}

</script>