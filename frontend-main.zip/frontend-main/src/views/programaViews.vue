<template>
    <div >
      <programa></programa> 
    </div>
  </template>
  
  <script>
  import programa from '@/components/programa.vue'
  export default {
  components:{
    programa
  }
  
  }
  
  </script>