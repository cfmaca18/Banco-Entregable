<template>
  <div >
    <rol></rol> 
  </div>
</template>

<script>
import rol from '@/components/Rol.vue'
export default {
components:{
rol
}

}

</script>