<template>
    <div >
      <centro></centro>
    </div>
  </template>
  
  <script>

  import centro from '@/components/centroFormacion.vue'

  export default {
   components:{
    centro,
  }
  
  }
    
  </script>
  