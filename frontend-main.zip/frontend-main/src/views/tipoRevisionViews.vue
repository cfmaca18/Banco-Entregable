<template>
    <div >
      <tipoRevision></tipoRevision> 
    </div>
  </template>
  
  <script>
  import tipoRevision from '@/components/tipoRevision.vue'
  export default {
  components:{
    tipoRevision,
  }
  
  }
  
  </script>