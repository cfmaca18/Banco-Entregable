<template>
    <div >
      <categoria></categoria>
    </div>
</template>

<script>
import categoria from '@/components/categoria.vue'
export default {
 components:{
  categoria,
}

}
  
</script>