# from dataclasses import fields
# from django import forms
# from .models import 

# class contact_form (forms.Form):
#     asunto = forms.CharField(widget = forms.TextInput())
#     correo = forms.EmailField(widget = forms.TextInput())
#     texto = forms.CharField(widget = forms.Textarea())