from django.contrib import admin
from proyectos.models import *
# Register your models here.
admin.site.register(Regional)
admin.site.register(Centros_de_formacion) 
admin.site.register(Programa) 
admin.site.register(Ficha) 
admin.site.register(Rol) 
admin.site.register(Perfil) 
admin.site.register(Tipo_Revision) 
admin.site.register(Categoria) 
admin.site.register(Proyecto) 
admin.site.register(Equipo_trabajo) 
admin.site.register(Entrega) 
admin.site.register(Documento)